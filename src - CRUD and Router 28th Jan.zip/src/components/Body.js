import React,{Component} from 'react';

class Body extends Component
{

    constructor(){

            super();
            this.state ={

                    id:1,name:'raman',gender:"male"
            }
        this.updateState = this.updateState.bind(this);
        //this.funname = this.funname.bind(this);
    }
    updateState()
    {
        console.log('you have clicked on button');
        this.setState({name:'name is changed'});
    }
    render()
    {
        return(
            <div>
                        <p>
                        <button onClick = {this.updateState}>CLICK</button>
                        </p>

                        <h1> body </h1>
                        <h2>Id  : {this.state.id} </h2>
                        <h2>Name:   {this.state.name}</h2>
                        <h2>Gender:  {this.state.gender} </h2>

                        <div>
                        <Product propName={this.state.name} />

                        </div>


            </div>
        );
    }
}

class Product extends Component
{
    constructor()
    {
        super();

    }
    render()
    {

        return(

            <div>
                <h1> data from parent ... using prop : {this.props.propName} </h1>
            </div>
        )
    }

}
export default Body;