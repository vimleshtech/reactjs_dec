import React,{Component} from 'react';

class Product extends Component{

    constructor(){

        super();
        this.state={
                pid:'',
                pname:'',
                qty:0,
                price:0
        }

        this.pid = this.pid.bind(this);
        this.pname = this.pname.bind(this);
        this.qty = this.qty.bind(this);
        this.price = this.price.bind(this);

    }
    pid(event)
    {
        var d=event.target.value;
        this.setState({pid:d});


    }
    pname(event)
    {

        var d=event.target.value;
        this.setState({pname:d});
        
    }
    qty(event){


        
        var d=event.target.value;
        this.setState({qty:d});
        

    }
    price(event)
    {

        
        var d=event.target.value;
        this.setState({price:d});
        
    }

    render()
    {
        return(
            <div>
                <h1> Product Details </h1>
                
                 <h1>{this.props.match.params.id}</h1>

                <p>
                    Product Id : <input type="text" onChange={this.pid} />
                </p>
                <p>
                    Product Name : <input type="text" onChange={this.pname} />
                </p>
                <p>
                    Quantity : <input type="text" onChange={this.qty} />
                </p>
                <p>
                    Price : <input type="text" onChange={this.price} />
                </p>
                <h2> Output </h2>
                <p>
                    Product Id : {this.state.pid}
                    Product Name : {this.state.pname}
                    Product Quantity : {this.state.qty}
                    Product Price : {this.state.price}
                    Total Price : {this.state.qty * this.state.price}
                </p>
            </div>
        );
    }
}

export default Product;